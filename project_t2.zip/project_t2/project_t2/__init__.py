import os
import ConfigParser
import argparse

from pyramid.config import Configurator


def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    config = Configurator(settings=settings)
    config.add_static_view(name='static', path='static')
    config.add_route('home', '/')
    config.scan()
    return config.make_wsgi_app()
    
print "into __init__"
print __name__
if __name__ == "project_t2":
    config = {}
    if not os.path.isfile("config.ini"):
        f = open("config.ini", "w+")
        config_pars = ConfigParser.ConfigParser()
        config_pars.add_section("user")
        config_pars.set("user", "name", "ThisUser")
        config_pars.set("user", "age", "90")
        config_pars.add_section("corp_server")
        config_pars.set("corp_server", "url", "server.com")
        config_pars.set("corp_server", "corp", "Mega Inc")
        config_pars.write(f)
        f.close()
    else:
        f = open("config.ini", "r")
        config_pars = ConfigParser.ConfigParser()
        config_pars.readfp(f)
        for section in config_pars.sections():
            config[section] = {}
            for key, value in config_pars.items(section):
                config[section][key] = value
        f.close()
        print "Config: %s" % (config)
        # it outputs in console
    
   # parser = argparse.ArgumentParser()
   # parser.add_argument("--version", help="enter version of program here")
   # args = parser.parse_args() 
   # print "Script version: %s" % (args.version)
   # # output verison in console
