from pyramid.view import view_config


@view_config(route_name="home", renderer="templates/index.pt")
def my_view(request):
    return {"scripts": scripts,
            "styles": styles,
            "top_menu": top_menu,
            "bottom_menu": bottom_menu,
            "follow_us": follow_us,
            "plates": plates}
print "into views"


scripts = [{"file": "test.js"}]

styles = [{"file": "header.css"},
          {"file": "reset.css"},
          {"file": "common.css"},
          {"file": "footer.css"},
          {"file": "front-page.css"}]
          
top_menu = [{"title": "About us", "href": "#"},
            {"title": "Courses", "href": "#"},
            {"title": "|", "href": "#"},
            {"title": "Sign in", "href": "#"},
            {"title": "Sign up", "href": "#"}]
            
bottom_menu = [{"title": "About us", "href": "#"},
               {"title": "Courses", "href": "#"},
               {"title": "Terms", "href": "#"}]
               
follow_us = [{"file": "facebook-large.png", "href": "#"},
             {"file": "twitter-large.png", "href": "#"},
             {"file": "googlep-large.png", "href": "#"}]
             
lorem_ipsum = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, \
        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. \
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\
        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
        
plates = [{"color": "plate-green", "text": lorem_ipsum, "advert_text": "START RUBY COURSE NOW!",
           "advert_href": "#"},
           {"color": "plate-orange", "text": lorem_ipsum, "advert_text": "",
           "advert_href": ""},
           {"color": "plate-skyblue", "text": lorem_ipsum, "advert_text": "START RUBY COURSE NOW!",
           "advert_href": "#"},
           {"color": "plate-red", "text": lorem_ipsum, "advert_text": "",
           "advert_href": ""},
           {"color": "plate-salat", "text": lorem_ipsum, "advert_text": "START RUBY COURSE NOW!",
           "advert_href": "#"},
           {"color": "plate-skyblue", "text": lorem_ipsum, "advert_text": "",
           "advert_href": ""}]
             