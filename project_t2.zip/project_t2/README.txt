project_t2 README
